# BinanceMiner - Bot de Arbitraje de Criptomonedas (Mejoras de Seguridad)

Este documento detalla las mejoras de seguridad implementadas en el bot de arbitraje de criptomonedas BinanceMiner, así como las mejores prácticas recomendadas para su operación segura.

## 1. Mejoras de Seguridad Implementadas

### 1.1. Remediación de Vulnerabilidad Crítica: Clave Secreta de Sesión (`SESSION_SECRET`)

**Cambio:** Se eliminó el valor por defecto de la clave secreta de sesión (`"dev-secret-key"`) en `app.py`. Ahora, la aplicación depende exclusivamente de la variable de entorno `SESSION_SECRET`.

**Impacto:** Se elimina el riesgo de secuestro de sesiones y acceso no autorizado debido a una clave secreta predecible o por defecto.

**Acción Requerida:** Es **IMPRESCINDIBLE** configurar la variable de entorno `SESSION_SECRET` con un valor largo, aleatorio y único en cada despliegue de producción. Por ejemplo, puedes generar una con `os.urandom(24)` en Python.

### 1.2. Mejora en la Gestión de Claves API

**Cambio:** Se modificó `api_config.py` para que las claves API no se persistan en la base de datos. Ahora, la aplicación solo verifica si las variables de entorno para las claves API están configuradas, pero no las almacena en la base de datos.

**Impacto:** Reduce significativamente el riesgo de exposición de credenciales sensibles en caso de un compromiso de la base de datos.

**Acción Requerida:** Las claves API de los exchanges (`BINANCE_API_KEY`, `BINANCE_API_SECRET`, `KUCOIN_API_KEY`, `KUCOIN_API_SECRET`, `KUCOIN_PASSPHRASE`, etc.) deben ser configuradas como variables de entorno en el entorno de producción. Nunca deben ser codificadas directamente en el código fuente ni almacenadas en archivos de configuración no seguros.

### 1.3. Refactorización y Seguridad en la Ejecución de Comandos Externos

**Cambio:** La función `get_price_data` en `stable_trading_bot.py` ha sido refactorizada para utilizar un script de Node.js (`get_price.js`) separado y pasar los argumentos de forma segura a través de `subprocess.run`. Esto elimina la interpolación directa de variables en la cadena del script.

**Impacto:** Mitiga el riesgo potencial de inyección de comandos si, en el futuro, las entradas del usuario fueran a influir en los parámetros de esta función.

**Acción Requerida:** Mantener la práctica de pasar argumentos de forma segura a los comandos externos. Evitar la interpolación directa de cualquier entrada controlada por el usuario en comandos ejecutados por `subprocess.run` o funciones similares.

## 2. Mejores Prácticas de Seguridad Adicionales

### 2.1. Protección contra Inyección SQL

Aunque SQLAlchemy (ORM) ayuda a prevenir la mayoría de las inyecciones SQL, es crucial:

*   **Nunca construir consultas SQL crudas** concatenando directamente la entrada del usuario. Siempre usar los mecanismos de parametrización proporcionados por SQLAlchemy.
*   Realizar auditorías de código regulares para identificar y corregir cualquier patrón de consulta inseguro.

### 2.2. Fortalecimiento del Panel de Administración

El panel de administración es un objetivo de alto valor. Se recomienda implementar las siguientes medidas:

*   **Autenticación de Dos Factores (2FA):** Habilitar 2FA para todas las cuentas de administrador.
*   **Limitación de Intentos de Inicio de Sesión:** Implementar un mecanismo para bloquear temporalmente las cuentas después de múltiples intentos fallidos de inicio de sesión.
*   **Protección CSRF:** Asegurar que todas las rutas que aceptan solicitudes POST (especialmente las administrativas) estén protegidas contra ataques CSRF. Flask-WTF o Flask-CSRF pueden ayudar con esto.
*   **Registro de Auditoría:** Mantener un registro detallado de todas las acciones realizadas por los administradores.

### 2.3. Gestión Segura del Token del Bot de Telegram

El token del bot de Telegram es una credencial sensible. Asegúrate de:

*   **Almacenarlo como variable de entorno** (`TELEGRAM_BOT_TOKEN`) y nunca en el código fuente o en archivos de configuración públicos.
*   **Nunca exponerlo en el lado del cliente** (frontend).
*   Considerar la rotación periódica del token.

### 2.4. Gestión de Dependencias y Actualizaciones

*   **Escaneo Regular de Vulnerabilidades:** Utilizar herramientas como `pip-audit` (para Python) y `npm audit` (para Node.js) de forma regular para escanear las dependencias en busca de vulnerabilidades conocidas.
*   **Mantener Dependencias Actualizadas:** Actualizar las bibliotecas y frameworks a sus últimas versiones estables para beneficiarse de las correcciones de seguridad y mejoras de rendimiento.
*   **Congelar Dependencias:** Utilizar un archivo `requirements.txt` (para Python) y `package-lock.json` (para Node.js) para congelar las versiones exactas de las dependencias y asegurar la reproducibilidad del entorno.

## 3. Configuración del Entorno de Producción

Para una operación segura del bot en producción, asegúrate de configurar las siguientes variables de entorno:

*   `SESSION_SECRET`: Una cadena larga, aleatoria y única (ej. `os.urandom(24)`).
*   `DATABASE_URL`: La URL de conexión a tu base de datos PostgreSQL de producción.
*   `BINANCE_API_KEY`, `BINANCE_API_SECRET`, `KUCOIN_API_KEY`, `KUCOIN_API_SECRET`, `KUCOIN_PASSPHRASE`: Tus claves API reales para los exchanges. No las uses en entornos de desarrollo/prueba.
*   `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`: El token de tu bot de Telegram y el ID del chat para las notificaciones.

## Conclusión

La implementación de estas mejoras y el seguimiento de las mejores prácticas de seguridad son fundamentales para proteger el bot BinanceMiner y los datos de sus usuarios. La seguridad es un proceso continuo, y se recomienda realizar auditorías periódicas y mantenerse al tanto de las últimas amenazas y contramedidas.

